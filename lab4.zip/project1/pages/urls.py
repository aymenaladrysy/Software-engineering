from django.urls import path
from . import views

urlpatterns=[
    path('index',views.index,name='index'),
    path('abut',views.abut,name='abut'),
    path('students',views.students,name='students'),
    path('home',views.home,name='home'),
    path('prgraph',views.prgraph,name='prgraph'),
    path('setting',views.setting,name='setting'),
    path('classes',views.classes,name='classes'),
]