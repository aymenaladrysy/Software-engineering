from django.contrib import admin
from .models import Student

# admin.site.register(Student)

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'age', 'average_score')
    list_filter = ('age',)
    search_fields = ('full_name',)
    fieldsets = (
        ('المعلومات الشخصية', {
            'fields': ('full_name', 'age', 'profile_image')
        }),
        ('الدرجات', {
            'fields': (
                ('math_score', 'physics_score', 'chemistry_score'),
                ('biology_score', 'arabic_score', 'english_score'),
                'history_score'
            )
        }),
    )