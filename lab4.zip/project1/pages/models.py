from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator

class Student(models.Model):
    # معلومات أساسية
    full_name = models.CharField(max_length=100, verbose_name="الاسم الكامل")
    age = models.PositiveIntegerField(verbose_name="العمر")
    profile_image = models.ImageField(
        upload_to='students/profile_images/',
        blank=True,
        null=True,
        verbose_name="صورة الطالب"
    )
    
    # درجات المواد (لصف ثالث ثانوي)
    math_score = models.FloatField(
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name="درجة الرياضيات"
    )
    physics_score = models.FloatField(
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name="درجة الفيزياء"
    )
    chemistry_score = models.FloatField(
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name="درجة الكيمياء"
    )
    biology_score = models.FloatField(
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name="درجة الأحياء"
    )
    arabic_score = models.FloatField(
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name="درجة اللغة العربية"
    )
    english_score = models.FloatField(
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name="درجة اللغة الإنجليزية"
    )
    history_score = models.FloatField(
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name="درجة التاريخ"
    )
    
    # حساب المعدل التلقائي
    @property
    def average_score(self):
        scores = [
            self.math_score,
            self.physics_score,
            self.chemistry_score,
            self.biology_score,
            self.arabic_score,
            self.english_score,
            self.history_score
        ]
        return sum(scores) / len(scores)
    
    def str(self):
        return self.full_name

    class Meta:
        verbose_name = "طالب"
        verbose_name_plural = "الطلاب"