from django.shortcuts import render
from datetime import datetime
from .models import Student 

def index(request):
    context = {
        # نصوص
        "name": "aymen",
        "greeting": "Welcome to Django world",
        # "greeting": "مرحبا بك في عالم Django",
        
        # أرقام
        "price": 1234.567,
        "discount": 0.25,
        
        # تواريخ
        "today": datetime.now(),
        
        # قائمة
        "items": ["تفاح", "موز", "برتقال"],
        
        # قيم منطقية
        "is_active": True,
        
        # نص طويل
        "long_text": "هذا نص طويل جدًا يحتوي على الكثير من الكلمات ليتم تقطيعه.",
        
        # قيمة فارغة
        "empty_value": "",
    }
    return render(request, "pages/index.html", context)


def  abut(request):
    return render(request,"pages/abut.html")


def students(request):
    students = Student.objects.all().order_by('full_name')
    context = {'students': students}
    return render(request,"pages/students.html",context)


def home(request):
    return render(request,"pages/home.html")


def prgraph(request):
    return render(request,"pages/prgraph.html")


def setting(request):
    return render(request,"pages/setting.html")    


def classes(request):
    return render(request,"pages/classes.html") 