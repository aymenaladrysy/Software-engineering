from django.urls import path
from . import views
from .views import delete_student,delete_employee

urlpatterns=[
    path('index',views.index,name='index'),
    path('',views.home,name='home'),
    path('students',views.students,name='students'),
    path('add_student',views.add_student,name='add_student'),
    path('students/delete/<int:student_id>/', delete_student, name='delete_student'),

    path('employees_list', views.employees_list, name='employees_list'),
    path('add_employee', views.add_employee, name='add_employee'),
    path('employees_list/delete/<int:id>/', views.delete_employee, name='delete_employee'),
]