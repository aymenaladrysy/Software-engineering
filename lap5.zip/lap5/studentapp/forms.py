from django import forms
from django.core.validators import MinValueValidator, MaxValueValidator
from .models import Student,Employee

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = '__all__'
        widgets = {
            'full_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'أدخل الاسم الكامل'
            }),
            'age': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '15',
                'max': '25'
            }),
            'profile_image': forms.ClearableFileInput(attrs={
                'class': 'form-control',
                'accept': 'image/*'
            }),
            'math_score': forms.NumberInput(attrs={
                'class': 'form-control score-input',
                'step': '0.1',
                'min': '0',
                'max': '100'
            }),
            'physics_score': forms.NumberInput(attrs={
                'class': 'form-control score-input',
                'step': '0.1',
                'min': '0',
                'max': '100'
            }),
            'chemistry_score': forms.NumberInput(attrs={
                'class': 'form-control score-input',
                'step': '0.1',
                'min': '0',
                'max': '100'
            }),
            'biology_score': forms.NumberInput(attrs={
                'class': 'form-control score-input',
                'step': '0.1',
                'min': '0',
                'max': '100'
            }),
            'arabic_score': forms.NumberInput(attrs={
                'class': 'form-control score-input',
                'step': '0.1',
                'min': '0',
                'max': '100'
            }),
            'english_score': forms.NumberInput(attrs={
                'class': 'form-control score-input',
                'step': '0.1',
                'min': '0',
                'max': '100'
            }),
            'history_score': forms.NumberInput(attrs={
                'class': 'form-control score-input',
                'step': '0.1',
                'min': '0',
                'max': '100'
            }),
        }
        labels = {
            'full_name': 'الاسم الكامل',
            'age': 'العمر',
            'profile_image': 'الصورة الشخصية',
            'math_score': 'درجة الرياضيات',
            'physics_score': 'درجة الفيزياء',
            'chemistry_score': 'درجة الكيمياء',
            'biology_score': 'درجة الأحياء',
            'arabic_score': 'درجة اللغة العربية',
            'english_score': 'درجة اللغة الإنجليزية',
            'history_score': 'درجة التاريخ'
        }
        help_texts = {
            'profile_image': 'يفضل صورة بخلفية بيضاء',
            'math_score': 'يجب أن تكون بين 0 و 100',
            'physics_score': 'يجب أن تكون بين 0 و 100',
            'chemistry_score': 'يجب أن تكون بين 0 و 100',
            'biology_score': 'يجب أن تكون بين 0 و 100',
            'arabic_score': 'يجب أن تكون بين 0 و 100',
            'english_score': 'يجب أن تكون بين 0 و 100',
            'history_score': 'يجب أن تكون بين 0 و 100'
        }

    def clean(self):
        cleaned_data = super().clean()
        errors = {}
        
        # التحقق من العمر
        age = cleaned_data.get('age')
        if age and (age < 15 or age > 25):
            errors['age'] = 'العمر يجب أن يكون بين 15 و 25 سنة'
        
        # التحقق من الدرجات
        score_fields = ['math_score', 'physics_score', 'chemistry_score',
                       'biology_score', 'arabic_score', 'english_score', 'history_score']
        
        for field in score_fields:
            score = cleaned_data.get(field)
            if score is not None and (score < 0 or score > 100):
                errors[field] = f'يجب أن تكون {self.fields[field].label} بين 0 و 100'
        
        if errors:
            raise forms.ValidationError(errors)
        
        return cleaned_data




# EmployeeForm

class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = '__all__'
        widgets = {
            'join_date': forms.DateInput(attrs={'type': 'date'}),
        }
