from django.shortcuts import render, redirect
from django.shortcuts import get_object_or_404, redirect
from django.contrib import messages
from django.views.decorators.http import require_POST
from django.http import JsonResponse
from .forms import StudentForm,EmployeeForm
from .models import Student,Employee

def add_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST, request.FILES)
        if form.is_valid():
            student = form.save()
            messages.success(request, f'تمت إضافة الطالب {student.full_name} بنجاح')
            return redirect('students')  # استبدل باسم view القائمة
    else:
        form = StudentForm()
    
    return render(request, 'pageStudent/add_student.html', {'form': form})

# Create your views here.

def index(request):
    return render(request,"pageStudent/index.html")

def delete_student(request, student_id):
    student = get_object_or_404(Student, id=student_id)
    if request.method == 'POST':
        student_name = student.full_name
        student.delete()
        messages.success(request, f'تم حذف الطالب {student_name} بنجاح')
        return redirect('students')
    
    return render(request, 'pageStudent/students.html', {'students': student})



def home(request):
    return render(request,"pageStudent/home.html")

def students(request):
    students = Student.objects.all().order_by('full_name')
    context = {'students': students}
    return render(request,"pageStudent/students.html",context)



def employees_list(request):
    employees = Employee.objects.all()
    return render(request, 'pageEmployees/employees_list.html', {'employees': employees})

def add_employee(request):
    if request.method == 'POST':
        form = EmployeeForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('employees_list')
    else:
        form = EmployeeForm()
    return render(request, 'pageEmployees/add_employee.html', {'form': form})

def delete_employee(request, id):
    employee = Employee.objects.get(id=id)
    employee.delete()
    return redirect('employees_list')
