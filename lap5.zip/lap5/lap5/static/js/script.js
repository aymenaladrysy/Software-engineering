// معاينة الصورة قبل الرفع
document.getElementById('id_image').addEventListener('change', function(e) {
    const preview = document.getElementById('imagePreview');
    const file = e.target.files[0];
    
    if (file) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.classList.remove('d-none');
        }
        
        reader.readAsDataURL(file);
    } else {
        preview.src = "#";
        preview.classList.add('d-none');
    }
});

// التحقق من صحة النموذج
(function () {
    'use strict'
    
    const forms = document.querySelectorAll('.needs-validation')
    
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            
            form.classList.add('was-validated')
        }, false)
    })
})();

// رسائل التأكيد
function confirmDelete() {
    return confirm('هل أنت متأكد من حذف هذا الموظف؟');
}